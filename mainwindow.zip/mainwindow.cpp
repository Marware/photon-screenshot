#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QRubberBand>
#include <QMouseEvent>
#include <QDesktopWidget.h>
#include <QDebug>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkReply>
#include <QHttpMultiPart>
#include <QHttpPart>
#include "localsocketipc.h"
//#include <QxtGlobalShortcut>
#ifdef Q_OS_WIN
#include <windows.h>
#elif Q_OS_MAC
//e3ml
#endif

bool CLOSED = false;
QRect go;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{


    ui->setupUi(this);
    ui->gSize->setParent(this);

    ui->gVbtns->hide();
    ui->gHbtns->hide();
    ui->gSize->hide();
    ui->gShbtns->hide();
    ui->gSelect->show();

    {
        ui->gSize->setAutoFillBackground(true);
        QPalette palette;
        palette.setBrush(QPalette::Window, QColor("grey"));
        ui->gSize->setPalette(palette);
    }

    drawSizeLabel();

    centralWidget()->setMouseTracking(true);
    setMouseTracking(true);

    setContextMenuPolicy(Qt::CustomContextMenu);
    connect(this, SIGNAL(customContextMenuRequested(const QPoint&)),
            this, SLOT(ShowContextMenu(const QPoint&)));

    go = QApplication::desktop()->availableGeometry();

    m_client = new LocalSocketIpcClient("cloudpic", this);
    m_server = new LocalSocketIpcServer("cloudpic_menuitem", this);
    connect(m_server, SIGNAL(messageReceived(QString)), this, SLOT(filesReceived(QString)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

//Main Screen Shot Rectangle : 20 - A
//- Take screen shot A1
//- ..save it on Qwidget A2
//- Set resizable rectangle to crop A3
//- save image temp : tmpImg A4
//- save on disk : save dialog A5

/* Main Screen Shot Rectangle : 20 - A */


void MainWindow::screenShot() // A1
{
    SetWindowPos(this->winId(), HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->showFullScreen();

    QDesktopWidget *d = QApplication::desktop();
    this->setGeometry(d->screen()->geometry());

    originalPixmap = QPixmap::grabWindow(QApplication::desktop()->winId());//esktop()->winId());
    QPalette palette;
    palette.setBrush(this->backgroundRole(), QBrush(originalPixmap));
    this->setPalette(palette);

    SetWindowPos(this->winId(), HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
    this->setFocus();
}

void MainWindow::redrawWindow() // A2
{


    //    QPainter *p = new QPainter();
    //    p->begin(this);
    //    p->setOpacity(0.5);
    //    QBrush b = QBrush(Qt::black);
    //    p->setBrush(b);
    //    p->drawRect(this->rect());
    //    p->end();

    //SetWindowPos(this->winId(), HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    //this->setWindowFlags(Qt::WindowStaysOnTopHint);
    // this->setWindowFlags(Qt::FramelessWindowHint);
    // this->setWindowState(Qt::WindowFullScreen);
    //this->setWindowFlags(Qt::WA_PaintOutsidePaintEvent);
    //this->setWindowOpacity(0.5);
    //  this->show();
}

//void MainWindow::cropRect() // A3
//{

//}

int i=0;
QString MainWindow::saveTmpImage(QString fn) // A4
{
    QRect area = rubberBand->geometry();
    rubberBand->hide();
    buttsHide();
    ui->gSize->hide();
    qWarning() << "SHOT";
    QPixmap pixmap(rubberBand->size());
    this->render(&pixmap, QPoint(), QRegion(area));
    if(fn.isEmpty())
    {
        fn = QString::number(qrand())+".png";
    }
    pixmap.save(fn);
    i++;
    ui->gSize->show();
    repositionButts();
    rubberBand->show();
    return fn;
}

//void MainWindow::saveImage() // A5
//{

//}
QMenu *menu;
QSystemTrayIcon *icon;

int MainWindow::tray() //K
{
    //    Take ScreenShot K1
    //    Quit K2

    //    QxtGlobalShortcut* shortcut = new QxtGlobalShortcut();
    //        connect(shortcut, SIGNAL(activated()), this, SLOT(shotSlot()));
    //        shortcut->setShortcut(QKeySequence(Qt::Key_));

    //this->setToolTip("Select area");


    menu = new QMenu();
    icon = new QSystemTrayIcon();

    connect(icon, SIGNAL(activated(QSystemTrayIcon::ActivationReason)), this, SLOT(iconClick(QSystemTrayIcon::ActivationReason)));

    QAction* shot = new QAction(tr("Take ScreenShot"), this);
    connect(shot, SIGNAL(triggered()), this, SLOT(shotSlot()));

    QAction* quit = new QAction(tr("&Quit"), this);
    connect(quit, SIGNAL(triggered()), this, SLOT(quit()));

    menu->addAction(shot);
    menu->addAction(quit);

    icon->setContextMenu(menu);
    icon->setToolTip("CloudPic");
    icon->setIcon(QIcon(QApplication::applicationDirPath()+ "/" +"logo.ico"));
    icon->setVisible(true);
    icon->show();
    return 0;
}

//void MainWindow::shotSlot() //K1
//{

//}

void MainWindow::ShowContextMenu(const QPoint& pos)
{
    QPoint globalPos = this->mapToGlobal(pos);
    // for QAbstractScrollArea and derived classes you would use:
    // QPoint globalPos = myWidget->viewport()->mapToGlobal(pos);

    QMenu m;
    QAction* upload = m.addAction("Upload");
    QAction* print = m.addAction("Print");
    QAction* copy = m.addAction("Copy");
    QAction* save = m.addAction("Save");
    QAction* fulls = m.addAction("Fullscreen");
    QAction* cls = m.addAction("Clear selection");
    QAction* cancel = m.addAction("Cancel");

    if(rubberBand == 0)
    {
        upload->setEnabled(false);
        print->setEnabled(false);
        copy->setEnabled(false);
        save->setEnabled(false);
        cls->setEnabled(false);
    }
    //    QAction* shot = new QAction(tr("Take ScreenShot"), this);
    //    connect(shot, SIGNAL(triggered()), this, SLOT(shotSlot()));
    QAction* selectedItem = m.exec(globalPos);
    if (selectedItem == upload)
    {
        on_gUpload_clicked();
    }
    if(selectedItem == print)
    {
        this->print();
    }
    if(selectedItem == copy)
    {
        copyImage();
    }
    if(selectedItem == save)
    {
        Saving();
    }
    if(selectedItem == fulls)
    {
        if(rubberBand == 0)
        {
            rubberBand = new Resizable_rubber_band(this);
            rubberBand->resize(0,0);
            connect(rubberBand, SIGNAL(buttsHide()),this,SLOT(buttsHide()));
            rubberBand->show();
        }

        setFullScreen();
        ui->gSelect->hide();
    }
    if(selectedItem == cls)
    {
        buttsHide();
        ui->gSize->hide();
        delete rubberBand;
        rubberBand = 0;
        this->repaint();
        this->update();

        QPoint p = QCursor::pos();
        p.setY(p.y()+30);
        ui->gSelect->move(p);
    }
    if(selectedItem == cancel)
    {
        closeCrop();
    }
    else
    {
        // nothing was chosen
    }
}

void MainWindow::iconClick(QSystemTrayIcon::ActivationReason t) //K4
{
    if(t == QSystemTrayIcon::Trigger)
    {
        shotSlot();
        //         this->activateWindow();
    }
}

void MainWindow::shotSlot() //K2
{
    if(!this->isVisible())
    {
        screenShot();
        ui->gSelect->show();
        // rubberBand->setVisible(false);
        rubberBand = 0;

        // this->show();
        CLOSED = false;
        //redrawWindow();
    }
    //SSetWindowsHookEx(WH_MOUSE_LL,MouseHookProc,NULL, 0);
}


void MainWindow::quit() //K2
{
    icon->setVisible(false);
    qApp->quit();
}

void MainWindow::moveToolTip(int x, int y)
{
    qWarning() << x << y;
    ui->gSelect->move(x,y);
}

bool kda;
void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if(event->button() == Qt::RightButton)
    {
        qWarning() << "righ";
        //event->ignore();
        return;
    }

    if (event->button() == Qt::LeftButton) {
        buttsHide();

        if(!rubberBand)
        {
            rubberBand = new Resizable_rubber_band(this);
            rubberBand->resize(0,0);
            connect(rubberBand, SIGNAL(buttsHide()),this,SLOT(buttsHide()));
        }
        origin = event->pos();
    }
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    if(event->button() == Qt::RightButton)
    {
        return;
    }
    if(event->buttons() & Qt::LeftButton)
    {
        rubberBand->setGeometry(QRect(origin, event->pos()).normalized());

        rubberBand->show();
        repositionSize();
        buttsHide();
        if(ui->gSelect->isVisible())
        {
            ui->gSelect->hide();
        }
    }
    else if(event->button() == Qt::NoButton)
    {
        if(ui->gSelect->isVisible() || rubberBand == 0)
        {
            QPoint p = event->pos();
            p.setY(p.y()+30);
            ui->gSelect->move(p);
            ui->gSelect->show();
        }
    }
}

QRect d;
bool g;
void Resizable_rubber_band::mouseMoveEvent(QMouseEvent *event)
{
    if (event->button() == Qt::RightButton) {
        event->ignore();
        down = false;
        return;
    }

    if (down) {
        QDesktopWidget *ds = QApplication::desktop();
        d = ds->screen()->geometry();
        //d = this->geometry();
        w = (MainWindow *) qApp->activeWindow();
        w->repositionSize();

        QPoint curPos = event->globalPos();

        if (curPos != lastPos) {
            QPoint diff = (lastPos - curPos);
            QRect r = geometry();

            if(geometry().right() >= d.right())
            {
                r.setRight(d.right());
                setGeometry(r);
            }

            if(geometry().top() <= d.top())
            {
                r.setTop(d.top());
                setGeometry(r);
            }

            if(geometry().left() <=  d.left())
            {
                r.setLeft(d.left());
                setGeometry(r);
            }

            if(geometry().bottom() >= d.bottom())
            {
                r.setBottom(d.bottom());
                setGeometry(r);
            }

            move(pos() - diff);
            //qWarning() << d;
            lastPos = curPos;
        }
    }
}

void Resizable_rubber_band::paintEvent(QPaintEvent *event)
{
    rubberband->hide();
    QPainter painter;
    QPen pen = QPen(Qt::black);

    pen.setStyle(Qt::DashLine);
    pen.setWidthF(0.8);
    painter.begin(this);
    painter.setPen(pen);
    QRect ev = event->rect();
    ev.setHeight(ev.height()-1);
    ev.setWidth(ev.width()-1);
    painter.drawRect(ev);
    painter.end();
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    //SetWindowPos(this->winId(), HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
    QPainter p;
    p.begin(this);
    p.fillRect(this->rect(),QColor(0x00, 0x00, 0x00, 0x80));
    if(rubberBand != 0)
    {
        p.eraseRect(rubberBand->geometry());
    }

    p.drawRect(this->geometry());
    p.end();
}

void Grip::paintEvent(QPaintEvent *event)
{


    QPainter p;
    p.begin(this);
    p.setBrush(Qt::black);
    p.setPen(Qt::white);

    QRect r = this->rect();
    int cx = r.x();
    int cy = r.y();
    p.drawRect(cx,cy, 5,5);
    p.end();
}

void Grip::mousePressEvent(QMouseEvent *e)
{
}

void Lab::mousePressEvent(QMouseEvent *e)
{
    w->gripMousePress(e);
}

QRect r;
void MainWindow::gripMousePress(QMouseEvent *e)
{
    if (e->button() == Qt::LeftButton) {

        lastPos = e->globalPos();
    }
}

void Grip::mouseMoveEvent(QMouseEvent *e)
{
    //w->gripMouseMove(e);
    e->accept();
}
bool u = true;
void Lab::mouseMoveEvent(QMouseEvent *e)
{
    if((cursor().shape() == Qt::SizeFDiagCursor) && (abs(w->lastPos.y() - w->t.topLeft().y()) <= 10) && (abs(w->lastPos.x() - w->t.topLeft().x()) <= 10))
    {
        w->gripMouseMove(e,1);
    }
    if((cursor().shape() == Qt::SizeVerCursor) && (abs(w->lastPos.y() - w->t.top()) <= 10) && (abs(w->lastPos.x() - w->t.center().x()) <= 10))
    {
        w->gripMouseMove(e,2);
    }
    if((cursor().shape() == Qt::SizeBDiagCursor) && (abs(w->lastPos.y() - w->t.topRight().y()) <= 10) && (abs(w->lastPos.x() - w->t.topRight().x()) <= 10))
    {
        w->gripMouseMove(e,3);
    }
    if((cursor().shape() == Qt::SizeHorCursor) && (abs(w->lastPos.y() - w->t.center().y()) <= 10) && (abs(w->lastPos.x() - w->t.right()) <= 10))
    {
        w->gripMouseMove(e,4);
    }

    if((cursor().shape() == Qt::SizeFDiagCursor) && (abs(w->lastPos.y() - w->t.bottomRight().y()) <= 10) && (abs(w->lastPos.x() - w->t.bottomRight().x()) <= 10))
    {
        w->gripMouseMove(e,5);
    }
    if((cursor().shape() == Qt::SizeVerCursor) && (abs(w->lastPos.y() - w->t.bottom()) <= 10) && (abs(w->lastPos.x() - w->t.center().x()) <= 10))
    {
        w->gripMouseMove(e,6);
    }

    if((cursor().shape() == Qt::SizeBDiagCursor) && (abs(w->lastPos.y() - w->t.bottomLeft().y()) <= 10) && (abs(w->lastPos.x() - w->t.bottomLeft().x()) <= 10))
    {
        w->gripMouseMove(e,7);
    }

    if((cursor().shape() == Qt::SizeHorCursor) && (abs(w->lastPos.y() - w->t.center().y()) <= 10) && (abs(w->lastPos.x() - w->t.left()) <= 10))
    {
        w->gripMouseMove(e,8);
    }
}

void MainWindow::gripMouseMove(QMouseEvent *e,int o)
{
    r = t;

    switch(o)
    {
    case 1:
        r.setTopLeft(e->globalPos());
        break;
    case 2:
        r.setTop(e->globalPos().y());
        break;
    case 3:
        r.setTopRight(e->globalPos());
        break;
    case 4:
        r.setRight(e->globalPos().x());
        break;
    case 5:
        r.setBottomRight(e->globalPos());
        break;
    case 6:
        r.setBottom(e->globalPos().y());
        break;
    case 7:
        r.setBottomLeft(e->globalPos());
        break;
    case 8:
        r.setLeft(e->globalPos().x());
        break;
    default:
        break;
    }

    rubberBand->setGeometry(r.normalized());
}

void Lab::mouseReleaseEvent(QMouseEvent *e)
{
    w->gripMouseRelease(e);
}


void MainWindow::gripMouseRelease(QMouseEvent *e)
{
    if(rubberBand->width() == 0 || rubberBand->height() == 0)
    {
        rubberBand->setGeometry(t.normalized());
    }
    repositionButts();
    t = rubberBand->geometry();
}

void Lab::paintEvent(QPaintEvent *event)
{
    QPainter p;
    p.begin(this);
    p.setBrush(Qt::black);
    p.setPen(Qt::white);

    QRect r = this->rect();
    int cx = r.x();
    int cy = r.y();
    p.drawRect(cx,cy, 5,5);
    p.end();
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{
    if(rubberBand)
    {
        if(rubberBand->height() == 0 || rubberBand->width() == 0)
        {
            buttsHide();
            ui->gSize->hide();
            delete rubberBand;
            rubberBand = 0;
            this->repaint();
            this->update();
            QPoint p = QCursor::pos();
            p.setY(p.y()+30);
            ui->gSelect->move(p);
            ui->gSelect->show();
            return;
        }
        if(rubberBand->geometry().height() > 1 && rubberBand->geometry().width() > 1)
        {
            repositionButts();
            t = rubberBand->geometry();
        }
    }
}

//void MainWindow::createButts()
//{
//    gHbtns = new QGroupBox(this);
//    gHbtns->setObjectName(QString::fromUtf8("gHbtns"));
//    gHbtns->setGeometry(QRect(110, 270, 281, 41));
//    gHbtns->setAutoFillBackground(false);
//    gHbtns->setStyleSheet(QString::fromUtf8("background-color: rgb(223, 223, 223);"));
//    gHbtns->setFlat(false);
//    gHbtns->setCheckable(false);
//    gPrint = new QPushButton(gHbtns);
//    gPrint->setObjectName(QString::fromUtf8("gPrint"));
//    gPrint->setGeometry(QRect(120, 0, 41, 41));
//    gPrint->setFlat(true);
//    gSave = new QPushButton(gHbtns);
//    gSave->setObjectName(QString::fromUtf8("gSave"));
//    gSave->setGeometry(QRect(200, 0, 41, 41));
//    gSave->setFlat(true);
//    gCopy = new QPushButton(gHbtns);
//    gCopy->setObjectName(QString::fromUtf8("gCopy"));
//    gCopy->setGeometry(QRect(160, 0, 41, 41));
//    gCopy->setFlat(true);
//    gUpload = new QPushButton(gHbtns);
//    gUpload->setObjectName(QString::fromUtf8("gUpload"));
//    gUpload->setGeometry(QRect(0, 0, 41, 41));
//    gUpload->setFlat(true);
//    gGoogImg = new QPushButton(gHbtns);
//    gGoogImg->setObjectName(QString::fromUtf8("gGoogImg"));
//    gGoogImg->setGeometry(QRect(80, 0, 41, 41));
//    gGoogImg->setFlat(true);
//    gClose = new QPushButton(gHbtns);
//    gClose->setObjectName(QString::fromUtf8("gClose"));
//    gClose->setGeometry(QRect(240, 0, 41, 41));
//    gClose->setAutoFillBackground(false);
//    gClose->setFlat(true);
//    gShare = new QPushButton(gHbtns);
//    gShare->setObjectName(QString::fromUtf8("gShare"));
//    gShare->setGeometry(QRect(40, 0, 41, 41));
//    gShare->setFlat(true);
//    gVbtns = new QGroupBox(this);
//    gVbtns->setObjectName(QString::fromUtf8("gVbtns"));
//    gVbtns->setGeometry(QRect(410, 60, 31, 211));
//    pushButton_9 = new QPushButton(gVbtns);
//    pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
//    pushButton_9->setGeometry(QRect(0, 150, 31, 31));
//    pushButton_8 = new QPushButton(gVbtns);
//    pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
//    pushButton_8->setGeometry(QRect(0, 180, 31, 31));
//    pushButton_10 = new QPushButton(gVbtns);
//    pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
//    pushButton_10->setGeometry(QRect(0, 120, 31, 31));
//    pushButton_12 = new QPushButton(gVbtns);
//    pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));
//    pushButton_12->setGeometry(QRect(0, 90, 31, 31));
//    pushButton_11 = new QPushButton(gVbtns);
//    pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));
//    pushButton_11->setGeometry(QRect(0, 60, 31, 31));
//    pushButton_14 = new QPushButton(gVbtns);
//    pushButton_14->setObjectName(QString::fromUtf8("pushButton_14"));
//    pushButton_14->setGeometry(QRect(0, 0, 31, 31));
//    pushButton_13 = new QPushButton(gVbtns);
//    pushButton_13->setObjectName(QString::fromUtf8("pushButton_13"));
//    pushButton_13->setGeometry(QRect(0, 30, 31, 31));
//    gSize = new QLabel(this);
//    gSize->setObjectName(QString::fromUtf8("gSize"));
//    gSize->setGeometry(QRect(80, 40, 91, 21));
//    gSize->setScaledContents(true);
//    gShbtns = new QGroupBox(this);
//    gShbtns->setObjectName(QString::fromUtf8("gShbtns"));
//    gShbtns->setGeometry(QRect(120, 310, 161, 21));
//    gShbtns->setAutoFillBackground(false);
//    gShbtns->setStyleSheet(QString::fromUtf8("background-color: rgb(223, 223, 223);"));
//    gShbtns->setFlat(false);
//    gShbtns->setCheckable(false);
//    gfb = new QPushButton(gShbtns);
//    gfb->setObjectName(QString::fromUtf8("gfb"));
//    gfb->setGeometry(QRect(0, 0, 41, 21));
//    gfb->setFlat(true);
//    gtw = new QPushButton(gShbtns);
//    gtw->setObjectName(QString::fromUtf8("gtw"));
//    gtw->setGeometry(QRect(40, 0, 41, 21));
//    gtw->setFlat(true);
//    gpin = new QPushButton(gShbtns);
//    gpin->setObjectName(QString::fromUtf8("gpin"));
//    gpin->setGeometry(QRect(80, 0, 41, 21));
//    gpin->setFlat(true);
//    gvk = new QPushButton(gShbtns);
//    gvk->setObjectName(QString::fromUtf8("gvk"));
//    gvk->setGeometry(QRect(120, 0, 41, 21));
//    gvk->setFlat(true);
//    gSelect = new QLabel(this);
//    gSelect->setObjectName(QString::fromUtf8("gSelect"));
//    gSelect->setGeometry(QRect(40, 350, 61, 16));
//    gSelect->setMouseTracking(true);
//    gSelect->setAutoFillBackground(false);
//    gSelect->setStyleSheet(QString::fromUtf8("background-color: rgb(221, 222, 124);\n"));

//    gHbtns->setTitle(QString());
//    gPrint->setText(QApplication::translate("MainWindow", "Print", 0, QApplication::UnicodeUTF8));
//    gSave->setText(QApplication::translate("MainWindow", "Save", 0, QApplication::UnicodeUTF8));
//    gCopy->setText(QApplication::translate("MainWindow", "Copy", 0, QApplication::UnicodeUTF8));
//    gUpload->setText(QApplication::translate("MainWindow", "Upload", 0, QApplication::UnicodeUTF8));
//    gGoogImg->setText(QApplication::translate("MainWindow", "Google\nImages", 0, QApplication::UnicodeUTF8));
//    gClose->setText(QApplication::translate("MainWindow", "Close", 0, QApplication::UnicodeUTF8));
//    gShare->setText(QApplication::translate("MainWindow", "Share", 0, QApplication::UnicodeUTF8));
//    gVbtns->setTitle(QString());
//    pushButton_9->setText(QString());
//    pushButton_8->setText(QString());
//    pushButton_10->setText(QString());
//    pushButton_12->setText(QString());
//    pushButton_11->setText(QString());
//    pushButton_14->setText(QString());
//    pushButton_13->setText(QString());
//    gSize->setText(QString());
//    gShbtns->setTitle(QString());
//    gfb->setText(QApplication::translate("MainWindow", "FB", 0, QApplication::UnicodeUTF8));
//    gtw->setText(QApplication::translate("MainWindow", "Tw", 0, QApplication::UnicodeUTF8));
//    gpin->setText(QApplication::translate("MainWindow", "Pin", 0, QApplication::UnicodeUTF8));
//    gvk->setText(QApplication::translate("MainWindow", "vk", 0, QApplication::UnicodeUTF8));
//    gSelect->setText(QApplication::translate("MainWindow", "Select area", 0, QApplication::UnicodeUTF8));
//}

void MainWindow::drawSizeLabel()
{

    ui->gSize->setAutoFillBackground(true);
    QPalette palette;
    palette.setBrush(QPalette::Window, QColor("grey"));
    ui->gSize->setPalette(palette);
}

QRect area;
QDesktopWidget* ds;
QRect scrn;
QRect hb;
QRect vb;
QPoint hbt;
QPoint vbt;
int h_st;
int v_st;

void MainWindow::repositionButts()
{
    /* Read Notes
      might rewrite the whole function
      fuck
      */

    ds = QApplication::desktop();
    scrn = ds->screen()->geometry();
    area = rubberBand->geometry();
    hb = ui->gHbtns->geometry();
    vb = ui->gVbtns->geometry();

    /* STATES */
    bool no_rt = false;
    bool no_bott = false;
    bool no_top = false;
    bool no_lf = false;
    bool fulls = false;

    bool vb_top = false;
    /* END OF STATES */

    /* DEFAULT */
    vb.moveLeft(area.right() + 10);
    vb.moveBottom(area.bottom());
    hb.moveRight(area.right());
    hb.moveTop(area.bottom()+10);
    /* EOF DEFAULT */

    /* POSITIONS CONDITIONS */
    //if(abs(scrn.bottom() - area.bottom()) < hb.height() + 10)
    if(scrn.bottom() - hb.bottom() < 5)
    {
        no_bott = true;
    }
    if(vb.top() - scrn.top() < 5)
    {
        no_top = true;
    }
    if(scrn.right() - vb.right() < 5)
    {
        no_rt = true;
    }
    if(hb.left() - scrn.left() < 5)
    {
        no_lf = true;
    }

    if(area.top()-scrn.top()< hb.height()+10 && scrn.bottom()-area.bottom()<hb.height()+10)
    {
        no_top = true;
        no_bott = true;
    }
    if(area.left()-scrn.left()< vb.width()+10 && scrn.right()-area.right() < vb.width()+10)
    {
        no_rt = true;
        no_lf = true;
    }
    /* EOF POS CONDS */

    if(no_top && no_bott)
    {
        band_tb();
    }
    else
    {

        if(no_bott)
        {
            bandBottom();
        }
        if(no_top)
        {
            bandTop();
        }
    }

    if(no_rt && no_lf)
    {
        band_rl();
    }
    else
    {
        if(no_rt)
        {
            bandRight();
        }

        if(no_lf)
        {
            bandLeft();
        }
    }

    if(vb.intersects(hb))
    {
        butts_intersect();
    }
    if(scrn == area)
    {
        bandFS();
    }
    //ui->gSize->move(szp.x(),szp.y());
    ui->gHbtns->setGeometry(hb);
    ui->gVbtns->setGeometry(vb);

    ui->gVbtns->setParent(this);
    ui->gVbtns->show();
    ui->gVbtns->raise();
    ui->gHbtns->setParent(this);
    ui->gHbtns->show();
    ui->gHbtns->raise();
}

/* BUTTS STATES FUNCTIONS */
void MainWindow::bandLeft()
{
    hb.moveLeft(scrn.left()+5);
}

void MainWindow::bandTop()
{
    vb.moveTop(scrn.top()+5);
}

void MainWindow::bandRight()
{
    vb.moveRight(area.left() - 10);
}

void MainWindow::bandBottom()
{
    hb.moveBottom(area.top()-10);
}

void MainWindow::band_rl()
{
    vb.moveRight(area.right()-10);
    vb.moveBottom(area.bottom()-10);

    if(vb.top() - scrn.top() < 10 || scrn.bottom() - vb.bottom() < 10)
    {
        vb.moveRight(hb.left()-10);

        if(hb.bottom() < area.top())
        {
            vb.moveBottom(hb.bottom());
        }
        else
        {
            vb.moveTop(hb.top());
        }
    }
}

void MainWindow::band_tb()
{
    hb.moveRight(area.right()-10);
    hb.moveBottom(area.bottom()-10);

    if(hb.left() - scrn.left() < 10 || scrn.right() - hb.right() < 10)
    {
        //hb.moveRight(hb.left()-10);

        if(vb.left() > area.right())
        {
            hb.moveLeft(area.right()+10);
        }
        else
        {
            hb.moveRight(area.left()+10);
        }
    }
}

void MainWindow::butts_intersect()
{
    if(abs(scrn.left()-area.left()) < abs(scrn.right()-area.right()))
    {
        vb.moveLeft(hb.right()+10);
    }
    else
    {
        vb.moveRight(hb.left()-10);
    }
}

void MainWindow::bandFS()
{
    hb.moveRight(area.right()-10);
    hb.moveBottom(area.bottom()-10);

    vb.moveRight(hb.left()-10);
    vb.moveBottom(area.bottom()-10);
}

void MainWindow::repositionSize()
{
    QRect area = rubberBand->geometry();
    QDesktopWidget *ds = QApplication::desktop();
    QRect scg = ds->screen()->geometry();

    QPoint szp;

    szp.setX(area.x());
    szp.setY(area.y()-(ui->gSize->height())-5);

    if(abs(area.top() - scg.top()) < ui->gSize->height()+20)
    {
        //szp.setX(area.topLeft().x()+5);
        szp.setY(area.topLeft().y()+5);
    }
    if(abs(area.left() - scg.right()) < ui->gSize->width()+5)
    {
        szp.setX(area.topRight().x()-(ui->gSize->width())-1);
        //szp.setY(area.topLeft().y()+5);
    }
    else
    {

    }

    ui->gSize->setParent(this);
    ui->gSize->move(szp.x(),szp.y());
    ui->gSize->setText("    "+QString::number(area.width())+"x"+QString::number(area.height()));
    ui->gSize->show();
}

Grip::Grip(QWidget *parent) : QSizeGrip (parent)
{
    w = (MainWindow *) qApp->activeWindow();
}

Lab::Lab(QWidget *parent) : QLabel (parent)
{
    w = (MainWindow *) qApp->activeWindow();
    //setCursor(Qt::SizeFDiagCursor);
}

bool ko = true;
Resizable_rubber_band::Resizable_rubber_band(QWidget *parent) : QWidget(parent) {

    setWindowFlags(Qt::FramelessWindowHint);
    setWindowFlags(Qt::SubWindow);
    setCursor(Qt::SizeAllCursor);

    layout = new QGridLayout(this);

    rubberband = new QRubberBand(QRubberBand::Rectangle, this);

    setMinimumSize(0,0);
    layout->setContentsMargins(0,0,0,-10);//L T R B

    grip1 = new Lab(this);
    grip2 = new Lab(this);
    grip3 = new Lab(this);
    grip4 = new Lab(this);
    grip5 = new Lab(this);
    grip6 = new Lab(this);
    grip7 = new Lab(this);
    grip8 = new Lab(this);

    grip1->setCursor(Qt::SizeFDiagCursor);
    grip2->setCursor(Qt::SizeVerCursor);
    grip3->setCursor(Qt::SizeBDiagCursor);
    grip4->setCursor(Qt::SizeHorCursor);
    grip5->setCursor(Qt::SizeFDiagCursor);
    grip6->setCursor(Qt::SizeVerCursor);
    grip7->setCursor(Qt::SizeBDiagCursor);
    grip8->setCursor(Qt::SizeHorCursor);

    layout->addWidget(grip1, 0,0,0,0, Qt::AlignTop | Qt::AlignLeft);
    layout->addWidget(grip2, 0,0,0,7, Qt::AlignTop | Qt::AlignCenter);
    layout->addWidget(grip3, 0,0,0,7, Qt::AlignTop | Qt::AlignRight);
    layout->addWidget(grip4, 0,0,7,7, Qt::AlignVCenter | Qt::AlignRight);
    layout->addWidget(grip5, 0,0,7,7, Qt::AlignBottom | Qt::AlignRight);
    layout->addWidget(grip6, 0,0,7,7, Qt::AlignBottom | Qt::AlignHCenter);
    layout->addWidget(grip7, 0,0,7,7, Qt::AlignBottom | Qt::AlignLeft);
    layout->addWidget(grip8, 0,0,7,7, Qt::AlignVCenter | Qt::AlignLeft);
    //v->addWidget(rubberband,0,0,0,0);

    layout->setSizeConstraint(QLayout::SetNoConstraint);
    this->setContentsMargins(0,0,0,-17); // Lab margins
    layout->addWidget(rubberband,0,0,0,0);
    rubberband->show();
}

void Resizable_rubber_band::resizeEvent(QResizeEvent *ev) {

    rubberband->resize(size());

    emit buttsHide();
    w = (MainWindow *) qApp->activeWindow();
    w->repositionSize();
}

void MainWindow::setFullScreen()
{
    rubberBand->setGeometry(QApplication::desktop()->screen()->geometry());
    repositionButts();
}

void Resizable_rubber_band::mouseDoubleClickEvent(QMouseEvent *event)
{
    w->setFullScreen();
}

void Resizable_rubber_band::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::RightButton) {
        down = false;
        event->ignore();
        return;
    }

    if (event->button() == Qt::LeftButton) {
        emit buttsHide();
        down = true;
        lastPos = event->globalPos();
    }
}

void MainWindow::buttsHide()
{
    ui->gHbtns->hide();
    ui->gVbtns->hide();
    ui->gShbtns->hide();
}

void Resizable_rubber_band::mouseReleaseEvent(QMouseEvent * event)
{
    w = (MainWindow *) qApp->activeWindow();
    w->repositionButts();
    down = false;
}

void Grip::mouseReleaseEvent(QMouseEvent * event)
{
    w = (MainWindow *) qApp->activeWindow();
    w->repositionButts();
}

bool MainWindow::eventFilter(QObject *object, QEvent *event)
{
    if (event->type() == QEvent::MouseButtonPress || event->type() == QEvent::MouseButtonRelease) {
        qWarning() << event->type();
    }
}

void MainWindow::on_gShare_clicked()
{
    sharer();
}

void MainWindow::sharer()
{
    QRect e = ui->gHbtns->geometry();
    ui->gShbtns->move(e.x()+20,e.y()+40);
    ui->gShbtns->show();
}

void MainWindow::on_gSave_clicked()
{
    Saving();
}

void MainWindow::Saving()
{
    saveAs();
}

QString MainWindow::saveAs()
{
    QString fn = QFileDialog::getSaveFileName(this, tr("Save as..."), "Screenshot_"+QString::number(i),tr("*.png;;*.jpg;;*.bmp"));

    if (fn.isEmpty())
        return "";
    if (! (fn.endsWith(".jpg", Qt::CaseInsensitive) || fn.endsWith(".jpeg", Qt::CaseInsensitive) || fn.endsWith(".png", Qt::CaseInsensitive) || fn.endsWith(".bmp", Qt::CaseInsensitive)) )
        fn += ".png"; // default
    saveTmpImage(fn);
    return fn;
}


bool MainWindow::copyImage()
{
    QString fn = saveTmpImage("");
    QImage image(fn);
    QApplication::clipboard()->setImage(image, QClipboard::Clipboard);
    QFile::remove(fn);
}

void MainWindow::on_gCopy_clicked()
{
    copyImage();
}

void MainWindow::print()
{
    QPrinter *printer = new QPrinter(QPrinter::HighResolution);
    QPrintDialog *dlg = new QPrintDialog(printer, this);

    if (dlg->exec() == QDialog::Accepted) {
        QString fn = saveTmpImage("");
        QImage img(fn);
        QPainter painter(printer);
        painter.drawImage(QPoint(0,0),img);
        painter.end();
    }
}

void MainWindow::on_gPrint_clicked()
{
    print();
}

void MainWindow::on_gClose_clicked()
{
    closeCrop();
}

void MainWindow::closeCrop()
{
    if(rubberBand)
    {
        rubberBand->hide();
        delete rubberBand;
    }
    buttsHide();
    ui->gSize->hide();
    this->close();
    CLOSED = true;
}

/************ LINKS AND SHARING ********************/
QString link;
bool linked = false;
QString filename;

QString MainWindow::getLink()
{
    uploader();
    //    while(link.isEmpty())
    //    {
    //        Sleep(1);
    //    }
    return link;
}

void MainWindow::createLink(QString uid)
{
    link = "http://cloudpic.co/"+uid;
    uploadFinishUi(link);
}

void MainWindow::openBrowser(QString lnk)
{
    //lnk = link;
    QDesktopServices::openUrl(QUrl(lnk, QUrl::TolerantMode));
}

void MainWindow::openBrowserB()
{
    QDesktopServices::openUrl(QUrl(link, QUrl::TolerantMode));
}

void MainWindow::copyText()
{
    QApplication::clipboard()->setText(link, QClipboard::Clipboard);
}

void MainWindow::fb_share(QString link)
{
    QString fb = "https://www.facebook.com/sharer/sharer.php?u="+link;
    openBrowser(fb);
}

void MainWindow::tw_share(QString link)
{
    QString tw = "https://twitter.com/home?status="+link;
    openBrowser(tw);
}

void MainWindow::vk_share(QString link)
{
    QString vk = "http://vk.com/share.php?url="+link;
    openBrowser(vk);
}

void MainWindow::pin_share(QString link)
{
    QString pin = "https://pinterest.com/pin/create/button/?url=&media=&description="+link;
    openBrowser(pin);
}

void MainWindow::goog_search(QString link)
{
    QString goog = "http://www.google.com/searchbyimage?image_url="+link;
    openBrowser(goog);
}

QNetworkReply *reply;
QNetworkAccessManager *manager;

void MainWindow::upload(QString fn)
{
    manager = new QNetworkAccessManager();
    QHttpMultiPart *multiPart = new QHttpMultiPart(QHttpMultiPart::FormDataType);
    QNetworkRequest request(QUrl("http://cloudpic.co/upload/process/"));

    fn = filename;

    QFileInfo finf(fn);
    qWarning() << "UPLOAD" << fn;

    QHttpPart imagePart;
    //request.setRawHeader("Cookie", phpsid.toAscii());
    imagePart.setHeader(QNetworkRequest::ContentDispositionHeader, QVariant("form-data; name=\"upload_file[]\"; filename=\""+finf.fileName()+"\""));
    imagePart.setHeader(QNetworkRequest::ContentTypeHeader, QVariant("*/*"));

    QFile f(fn);
    f.open(QIODevice::ReadOnly);

    imagePart.setBodyDevice(&f);
    f.setParent(multiPart);
    multiPart->append(imagePart);

    reply = manager->post(request, multiPart);
    multiPart->setParent(reply);


    connect(reply, SIGNAL(uploadProgress(qint64,qint64)), this, SLOT(uploadProgressBar(qint64,qint64)));

    QEventLoop eventLoop;
    connect(manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(networkReply(QNetworkReply*)));
    connect(manager, SIGNAL(finished(QNetworkReply *)), &eventLoop, SLOT(quit()));
    //connect(reply,SIGNAL(finished()),this,)
    eventLoop.exec();
}

void MainWindow::networkReply(QNetworkReply *rep)
{
    qWarning() << "FFSFS";
    QString rp;

    if(rep->attribute(QNetworkRequest::HttpStatusCodeAttribute).toString() == "200")
    {
        rp.append(rep->readAll());

        if(!rp.contains("fileupload"))
        {
            qWarning() << "ERROR";
        }
        else
        {
            QFileInfo fs(filename);
            progressBar->setValue(fs.size());
            parseReply(rp);
        }
    }
    //progressBar->setValue(s);

    //rep->deleteLater();
}

void MainWindow::parseReply(QString rep)
{
    //{"fileupload":["HsjAjIaG"]}

    QStringList l = rep.split(":",QString::KeepEmptyParts);
    QString lt = l.at(1);
    lt.remove("[\"");
    lt.remove("\"]}");
    qWarning() << lt;
    createLink(lt);
}

void MainWindow::uploadProgressBar(qint64 s,qint64 t)
{
    //QNetworkReply *rep  = (QNetworkReply*) sender();

    //int gsz = rep->request().rawHeader(rep->request().rawHeaderList().at(3)).toInt();
    progressBar->setValue(s);
    qWarning() << s;
    if(s == t)
    {
        linked = true;
    }
}

void MainWindow::ProgressForm(QString fn)
{
    QFileInfo f(fn);

    qWarning() << "Window" << f.size();
    gProgressForm = new QWidget(0);
    QRect r = go;
    gProgressForm->setWindowFlags (Qt::FramelessWindowHint |Qt::CustomizeWindowHint | Qt::WindowTitleHint | Qt::WindowStaysOnTopHint |  Qt :: WindowCloseButtonHint);
    gProgressForm->setWindowIcon(QIcon("logo"));
    //gProgressForm->setWindowFlags(eFlags);
    qWarning() << r;
    gProgressForm->setGeometry(r.width()-360-10,r.height()-50-50,360,70);
    gProgressForm->setObjectName(QString::fromUtf8("gProgressForm"));
    gProgressForm->resize(360, 50);
    gProgressForm->setMinimumSize(QSize(360, 50));
    gProgressForm->setMaximumSize(QSize(360, 50));
    gProgressForm->setWindowTitle("Uploading Image");
    progressBar = new QProgressBar(gProgressForm);
    progressBar->setObjectName(QString::fromUtf8("progressBar"));
    progressBar->setGeometry(QRect(110, 10, 241, 31));
    progressBar->setTextVisible(false);
    progressBar->setMinimum(0);
    progressBar->setMaximum(f.size());
    gCancelUp = new QPushButton(gProgressForm);
    gCancelUp->setObjectName(QString::fromUtf8("gCancelUp"));
    gCancelUp->setGeometry(QRect(20, 10, 60, 25));
    gCancelUp->setText("Cancel");

    connect(gProgressForm,SIGNAL(destroyed()),this,SLOT(upCancel()));
    connect(gCancelUp,SIGNAL(clicked()),this,SLOT(upCancel()));

    gProgressForm->setAttribute(Qt::WA_DeleteOnClose, true);
    gProgressForm->setWindowFlags (Qt::FramelessWindowHint |Qt::CustomizeWindowHint | Qt::WindowTitleHint | Qt::WindowStaysOnTopHint |  Qt :: WindowCloseButtonHint);
    gProgressForm->show();
    gProgressForm->raise();
    SetWindowPos(gProgressForm->winId(), HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
    gProgressForm->activateWindow();

}

void MainWindow::uploadFinishUi(QString uid)
{
    if(!reply)
    {
        return;
    }
    progressBar->hide();
    gCancelUp->hide();

    gOpurl = new QPushButton(gProgressForm);
    gOpurl->setObjectName(QString::fromUtf8("gOpurl"));
    gOpurl->setGeometry(QRect(5, 12, 75, 25));
    gCpurl = new QPushButton(gProgressForm);
    gCpurl->setObjectName(QString::fromUtf8("gCpurl"));
    gCpurl->setGeometry(QRect(90, 12, 75, 25));
    textEdit = new QTextEdit(gProgressForm);
    textEdit->setObjectName(QString::fromUtf8("textEdit"));
    textEdit->setGeometry(QRect(177, 12, 180, 25));
    textEdit->setText(uid);
    textEdit->selectAll();
    gOpurl->setText("Open");
    gCpurl->setText("Copy");
    connect(gOpurl,SIGNAL(clicked()),this,SLOT(openBrowserB()));
    connect(gCpurl,SIGNAL(clicked()),this,SLOT(copyText()));
    connect(gOpurl,SIGNAL(clicked()),gProgressForm,SLOT(close()));
    connect(gCpurl,SIGNAL(clicked()),gProgressForm,SLOT(close()));
    gOpurl->show();
    gCpurl->show();
    textEdit->show();
    gProgressForm->activateWindow();
    textEdit->raise();
    textEdit->activateWindow();
    SetWindowPos(gProgressForm->winId(), HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);

}

void MainWindow::stopUpload()
{
    gProgressForm->close();
    reply->abort();
}


void MainWindow::upCancel()
{
    reply->abort();
    gProgressForm->close();
}

/************ LINKS AND SHARING ********************/

void MainWindow::on_gfb_clicked()
{
    fb_share(getLink());
}

void MainWindow::on_gtw_clicked()
{
    tw_share(getLink());
}

void MainWindow::on_gpin_clicked()
{
    pin_share(getLink());
}

void MainWindow::on_gvk_clicked()
{
    vk_share(getLink());
}

void MainWindow::on_gGoogImg_clicked()
{
    goog_search(getLink());
}

void MainWindow::prepare_upload()
{
    QString fn = saveTmpImage("");
    filename = fn;
    closeCrop();
    ProgressForm(fn);
}

void MainWindow::uploader()
{
    upload(filename);
}

void MainWindow::on_gUpload_clicked()
{
    prepare_upload();
    getLink();
}


/* SHELLEX HANDLER */

void MainWindow::filesReceived(QString files)
{
    QStringList fs = files.split("|",QString::KeepEmptyParts);

    for(int fl=0; fl < fs.length(); fl++)
    {
        filename = fs.at(fl);
        uploader();
    }
}
